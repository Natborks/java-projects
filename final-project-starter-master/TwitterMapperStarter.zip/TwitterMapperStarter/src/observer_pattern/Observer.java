package observer_pattern;

import twitter4j.Status;

public interface Observer {
    void update(Object s);
}
