package observer_pattern;

import twitter4j.Status;

import java.util.ArrayList;
import java.util.List;

public abstract class Observable {
    protected List<Observer> observers;

    public Observable() {
        this.observers = new ArrayList<>();
    }

    protected void notifyObservers(Status s){
        for (Observer observer : observers){
            observer.update(s);
        }
    }

    public void registerObserver (Observer o) {
        observers.add(o);
    }

    public void removeObserver (Observer o) {
        observers.remove(o);
    }
}
