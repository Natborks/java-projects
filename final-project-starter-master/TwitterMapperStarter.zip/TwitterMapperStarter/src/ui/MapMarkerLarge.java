package ui;

import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.Layer;
import org.openstreetmap.gui.jmapviewer.interfaces.MapMarker;
import twitter4j.Status;

import java.awt.*;
import java.awt.image.BufferedImage;

public class MapMarkerLarge extends MapMarkerSimple {
    protected double defaultMarkerSize;
    protected BufferedImage image;
    public Color color;
    protected Status status;

    @Override
    public Color getColor() {
        return color;
    }

    public Status getStatus() {
        return status;
    }

    public MapMarkerLarge(Layer layer, Coordinate coord, Color color, Status status, double size) {
        super(layer, coord, size);
        this.status = status;
        defaultMarkerSize = size;
        this.color = color;
        setColor(Color.black);
        setBackColor(color);
    }

    public void setImage(BufferedImage image) throws NullPointerException{
        this.image = image;
    }


    @Override
    public void paint(Graphics g, Point position, int radius) {
        super.paint(g, position, radius);

        double r = this.getRadius();
        int width = (int) (defaultMarkerSize);
        int height = (int) (defaultMarkerSize);
        int yPos = height / 2;
        int xPos = width / 2;

        g.drawImage(this.image, position.x - xPos, position.y - yPos, width, height, null);
        this.paintText(g, position);
    }


    public String getToolTipText(){
        return status.getText();
    }
}
