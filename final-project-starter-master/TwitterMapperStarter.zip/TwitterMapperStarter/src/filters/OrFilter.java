package filters;

import twitter4j.Status;

import java.util.List;

public class OrFilter implements Filter{
    Filter child;
    Filter orChild;

    public OrFilter(Filter child, Filter orChild) {
        this.child = child;
        this.orChild = orChild;
    }

    @Override
    public boolean matches(Status s) {
        return child.matches(s) || orChild.matches(s);
    }

    @Override
    public List<String> terms() {
        return TermsCombiner.combineTerms(child.terms(), orChild.terms());
    }

    @Override
    public String toString() {
        return "(" + child + " or " + orChild + ')';
    }
}
