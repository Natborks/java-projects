package filters;

import java.util.LinkedList;
import java.util.List;

public class TermsCombiner {
    public static List<String> combineTerms(List<String> terms, List<String> terms1) {
        List<String> combinedTerms = new LinkedList<>();

        terms.addAll(terms1);

        return combinedTerms;
    }
}
