package filters;

import twitter4j.Status;

import java.util.LinkedList;
import java.util.List;

public class AndFilter implements Filter{
    private Filter child;
    private Filter andChild;

    public AndFilter(Filter child1, Filter child2) {
        child = child1;
        andChild = child2;
    }

    @Override
    public boolean matches(Status s) {
        return child.matches(s) && andChild.matches(s);
    }

    @Override
    public List<String> terms() {
       return TermsCombiner.combineTerms(child.terms(), andChild.terms());
    }

    @Override
    public String toString() {
        return "(" + child.toString() + " and " + andChild.toString() + ')';
    }
}
